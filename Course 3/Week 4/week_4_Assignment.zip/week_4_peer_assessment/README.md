Hello folks, 

You have to run 

meteor npm install

in this directory before you can run the application. 
